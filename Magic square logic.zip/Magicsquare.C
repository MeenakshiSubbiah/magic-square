# include <stdio.h>
# include <conio.h>
void drawbox(int a)
{
int meena;
for(meena=0;meena<a;meena++)
{
printf("-------") ;
}
//printf("-------") ;
}

int main()
{
int n, x, y, z, matrix[10][10] ;
printf("Please enter odd digit less than 10 : ") ;
scanf("%d", &n) ;
if (n % 2 == 0)
{
    printf("\nMagic square is not possible") ;
    goto end ;
}
printf("\nThe magic square for %d x %d is :\n\n", n, n) ;
y = (n + 1) / 2 ;
x = 1 ;
for(z = 1 ; z <= n * n ; z++)
{
matrix[x][y] = z ;
    // Hit Logic
        if(z % n == 0)
        {
            x = x++;
            goto loop ;
        }

// L Shape down
        if(x == 1) x = n ;
//Ladder Logic // L Shape up
        else x = x-- ;
//L Shape up
        if(y == n) y = 1;
//Ladder Logic // L Shape down

        else y = y++ ;
        loop : ;
}

drawbox(n);
printf("\n| ") ;
    for (x = 1 ; x <= n ; x++)
    {
        for (y = 1 ; y <= n ; y++)
        {
            if(matrix[x][y] < 10){ printf("0%d  |  ", matrix[x][y]) ;}
            else {printf("%d  |  ", matrix[x][y]) ;}
        }
        printf("\n");
            drawbox(n);
        if(x<n) printf("\n| ");
//    if(i==n) printf("\n---------------------\n") ;
//    else printf("\n---------------------\n| ") ;
    }
end : ;
getch() ;
return 0;
}

